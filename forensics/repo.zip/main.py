import os
def connect_to_db():
    print('Connecting to database...')
    password = os.getenv('DB_PASS')
